<?php
 // Silence is golden